class HomeController < ApplicationController
	def index
	end

	def create
	end

	def show
	end
end
